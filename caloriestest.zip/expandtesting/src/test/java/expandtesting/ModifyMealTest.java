package expandtesting;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.JavascriptExecutor;
import org.apache.commons.lang3.RandomStringUtils;
import java.time.Duration;
import java.util.Random;

public class ModifyMealTest {

    @Test
    void UpdateMeal() {
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        String url = "https://practice.expandtesting.com/tracalorie/";
        driver.get(url);

        String randomFoodItem = RandomStringUtils.randomAlphabetic(8);
        int randomCalories = new Random().nextInt(451) + 50;

        WebElement itemInput = driver.findElement(By.id("item-name"));
        itemInput.sendKeys(randomFoodItem);

        WebElement calorieInput = driver.findElement(By.id("item-calories"));
        calorieInput.sendKeys(String.valueOf(randomCalories));

        WebElement addMealButton = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Add Meal')]")));

        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", addMealButton);


        WebElement modifyButton = driver.findElement(By.cssSelector(".edit-item.fa.fa-pencil"));


        modifyButton.click();

        driver.quit();
    }
}